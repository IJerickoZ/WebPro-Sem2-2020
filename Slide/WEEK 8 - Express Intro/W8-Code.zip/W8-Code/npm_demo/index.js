const { localeUpperCase, upperCase } = require('upper-case')

console.log(upperCase('test 1234'))