// console.log('I am the first script')

// for (let i = 0; i <= 10; i++){
//   console.log(i)
// }

const md = require('./my_module')
console.log(md)
console.log(md.NAME)
console.log(md.add)
console.log(md.substract)

// const { NAME, add } = require('./myModule')
// console.log(NAME)
// console.log(add)